import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ProductManagementSystem {
    private final List<Product> products = new ArrayList<>();
    private final DefaultTableModel tableModel;

    public ProductManagementSystem() {
        // Frame Setup
        JFrame frame = new JFrame("Product Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        // Table Setup
        String[] columnNames = {"ID", "Name", "Price", "Category"};
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Buttons
        JButton addButton = new JButton("Add Product");
        JButton updateButton = new JButton("Update Product");
        JButton deleteButton = new JButton("Delete Product");
        JButton sortAscButton = new JButton("Sort: Low to High");
        JButton sortDescButton = new JButton("Sort: High to Low");

        // Panel for Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(sortAscButton);
        buttonPanel.add(sortDescButton);

        // Add components to frame
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Action Listeners
        addButton.addActionListener(e -> addProduct());
        updateButton.addActionListener(e -> updateProduct(table));
        deleteButton.addActionListener(e -> deleteProduct(table));
        sortAscButton.addActionListener(e -> sortProducts(true));
        sortDescButton.addActionListener(e -> sortProducts(false));

        frame.setVisible(true);
    }

    private void addProduct() {
        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField categoryField = new JTextField();

        Object[] message = {
            "Name:", nameField,
            "Price:", priceField,
            "Category:", categoryField,
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Add Product", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                String category = categoryField.getText();

                if (name.isEmpty() || category.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Name and Category cannot be empty!");
                    return;
                }

                Product product = new Product(name, price, category);
                products.add(product);
                updateTable();
                JOptionPane.showMessageDialog(null, "Product added successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid price value.");
            }
        }
    }

    private void updateProduct(JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please select a product to update.");
            return;
        }

        int id = (int) table.getValueAt(selectedRow, 0);
        Product product = products.stream().filter(p -> p.getId() == id).findFirst().orElse(null);

        if (product != null) {
            JTextField nameField = new JTextField(product.getName());
            JTextField priceField = new JTextField(String.valueOf(product.getPrice()));
            JTextField categoryField = new JTextField(product.getCategory());

            Object[] message = {
                "Name:", nameField,
                "Price:", priceField,
                "Category:", categoryField,
            };

            int option = JOptionPane.showConfirmDialog(null, message, "Update Product", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                try {
                    product.setName(nameField.getText());
                    product.setPrice(Double.parseDouble(priceField.getText()));
                    product.setCategory(categoryField.getText());
                    updateTable();
                    JOptionPane.showMessageDialog(null, "Product updated successfully!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid price value.");
                }
            }
        }
    }

    private void deleteProduct(JTable table) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(null, "Please select a product to delete.");
            return;
        }

        int id = (int) table.getValueAt(selectedRow, 0);
        products.removeIf(product -> product.getId() == id);
        updateTable();
        JOptionPane.showMessageDialog(null, "Product deleted successfully!");
    }

    private void sortProducts(boolean ascending) {
        products.sort(Comparator.comparingDouble(Product::getPrice));
        if (!ascending) {
            Collections.reverse(products);
        } 
        updateTable();
        JOptionPane.showMessageDialog(null, "Products sorted successfully!");
    }

    private void updateTable() { 
        tableModel.setRowCount(0); // Clear table
        for (Product product : products) {
            tableModel.addRow(new Object[]{product.getId(), product.getName(), product.getPrice(), product.getCategory()});
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(ProductManagementSystem::new);
    }
}
